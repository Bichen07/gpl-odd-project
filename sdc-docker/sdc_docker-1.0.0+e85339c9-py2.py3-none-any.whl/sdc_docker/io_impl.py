"""
Define interface and implementation of low-level I/O functions.

These are the low-level impure functions, implementation of which we
don't have access to. We have such decoupling for the purposes of testability,
as well as for making impurity of functions obvious due to the necessity of
passing the Io argument any time the function requires side-effects.
"""

from argparse import ArgumentParser, Namespace
from importlib import metadata
import inspect
import os
import shutil
import subprocess
from subprocess import CompletedProcess
import sys
import tempfile
from typing import Any, Mapping

import jinja2
import pkg_resources

class Io():
    """
    An interface, which an implementation of Io must adhere to.
    """

    def copytree(self,
            src: str,
            dest: str,
            symlinks: bool = False,
            dirs_exist_ok: bool = False) -> None:
        """ Copy `src` file-tree to `dest`. """
        raise NotImplementedError()

    def file_exists(self, path: str) -> bool:
        """
        Check whether a file exists.

        Args:
            path: path to the file of interest.

        Returns:
            True, if file exists, and False - otherwise.
        """
        raise NotImplementedError()

    def get_script_directory(self) -> str:
        """ Return a path to the directory of the script
        that calls this function. """
        raise NotImplementedError()

    def getenv(self, name: str) -> str:
        """ Return a value of a requested environment varible. """
        raise NotImplementedError()

    def getgid(self) -> int:
        """ Return an integer representing GID of the current user. """
        raise NotImplementedError()

    def getuid(self) -> int:
        """ Return an integer representing UID of the current user. """
        raise NotImplementedError()

    def log(self, message: str) -> None:
        """ Log a message. """
        raise NotImplementedError()

    def mkdtemp(self, prefix: str) -> str:
        """ Create temporary directory and return its path. """
        raise NotImplementedError()

    def parse_arguments(self, parser: ArgumentParser) -> Namespace:
        """
        Parse command-line arguments based on the provided parser and
        return the parsed arguments.
        """
        raise NotImplementedError()

    def putenv(self, name: str, value: str) -> None:
        """ Update value of an environment variable. """
        raise NotImplementedError()

    def read_file(self, path: str) -> str:
        """
        Return content of a file, which path is passed as an argument.
        """
        raise NotImplementedError()

    def render_jinja_template(self,
            path: str,
            searchpath: str,
            context: Mapping) -> str:
        """ Render Jinja template file located at `path`,
        with `searchpath` telling where to find template files referenced
        from the template file. Return the rendered content. """
        raise NotImplementedError()

    def resource_filename(self, package: str, resource: str) -> str:
        """
        Return path to a resource inside a python package.
        See `setuptools.pkg_resources.resource_filename` for more details.
        """
        raise NotImplementedError()

    def rmtree(self, path: str) -> None:
        """ Remove file-tree at `path`. """
        raise NotImplementedError()

    def subprocess_run(self, *args: Any, **kwargs: Any) -> CompletedProcess:
        """ Mock `subprocess.run()`. """
        raise NotImplementedError()

    def sys_executable(self) -> str:
        """ Mock `sys.executable`. """
        raise NotImplementedError()

    def version(self, distribution_name: str) -> str:
        """ Return version of package. """
        raise NotImplementedError()

    def write_file(self, path: str, data: str) -> None:
        """ Write data to the file. """
        raise NotImplementedError()

class IoImplementation(Io):
    """ Implementation of Io interface """

    def copytree(self,
            src: str,
            dest: str,
            symlinks: bool = False,
            dirs_exist_ok: bool = False) -> None:
        shutil.copytree(src, dest,
            symlinks=symlinks, dirs_exist_ok=dirs_exist_ok)

    def file_exists(self, path: str) -> bool:
        return os.path.exists(path)

    def get_script_directory(self) -> str:
        caller_globals = inspect.stack()[1][0].f_globals
        script_file = caller_globals["__file__"]
        return os.path.dirname(os.path.realpath(script_file))

    def getenv(self, name: str) -> str:
        return os.environ[name]

    def getgid(self) -> int:
        return os.getgid()

    def getuid(self) -> int:
        return os.getuid()

    def log(self, message: str) -> None:
        print(message)

    def mkdtemp(self, prefix: str) -> str:
        return tempfile.mkdtemp(prefix=prefix)

    def parse_arguments(self, parser: ArgumentParser) -> Namespace:
        return parser.parse_args()

    def putenv(self, name: str, value: str) -> None:
        os.putenv(name, value)

    def read_file(self, path: str) -> str:
        with open(path, "r") as f:
            return f.read()

    def render_jinja_template(self,
            path: str,
            searchpath: str,
            context: Mapping) -> str:
        env = jinja2.Environment(
            loader=jinja2.FileSystemLoader(searchpath=searchpath),
            undefined=jinja2.StrictUndefined)
        template = env.get_template(path)
        return template.render(context)

    def resource_filename(self, package: str, resource: str) -> str:
        return pkg_resources.resource_filename(package, resource)

    def rmtree(self, path: str) -> None:
        shutil.rmtree(path)

    def subprocess_run(self, *args: Any, **kwargs: Any) -> CompletedProcess:
        return subprocess.run(*args, **kwargs) # pylint: disable=subprocess-run-check

    def sys_executable(self) -> str:
        return sys.executable

    def version(self, distribution_name: str) -> str:
        return metadata.version(distribution_name)

    def write_file(self, path: str, data: str) -> None:
        with open(path, "w") as f:
            f.write(data)

def make_io() -> IoImplementation:
    """
    Return implementation of Io interface used by sdc-docker.
    """
    return IoImplementation()
