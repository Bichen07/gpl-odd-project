"""
Pretty-printing a dictionary.

Use it for reporting build facts and configuration values on the terminal.
"""

import textwrap as tw
from typing import Any, Dict, Tuple

import funcy as fc # type: ignore
from pyrsistent import thaw

def report_dict(
        dictionary: Dict[str, Any],
        indent: int = 0) -> str:
    """
    Make a string, representing a pretty-printed version of a dictionary.

    Args:
        dictionary: dictionary that is going to be pretty-printed.
        indent: indentation of the pretty-printed version.

    Returns:
        String, representing a pretty-printed dictionary
    """
    keys = sorted(dictionary.keys())
    key_column_width = max_key_column_width(dictionary, indent)
    def line(key: str) -> str:
        value = thaw(dictionary[key])
        indented_key = (" " * indent) + f"{key}:"
        if isinstance(value, dict):
            formatted_value = report_dict(value, indent + 2)
            return f"{indented_key}\n{formatted_value}"
        if isinstance(value, list):
            formatted_value = tw.indent(
                "\n".join(value), " " * (indent + 2))
            return f"{indented_key}\n{formatted_value}"
        padded_key = indented_key.ljust(key_column_width + 2)
        return f"{padded_key}{value}"
    return "\n".join(map(line, keys))

def max_key_column_width(dictionary: Dict[str, Any], indent: int) -> int:
    """
    Calculate maximum width (number of characters) of the key-column of
    a pretty-printed dictionary.

    Args:
        dictionary: dictionary that needs to be pretty-printed.
        indent: indentation of the pretty-printed dictionary.

    Returns:
        Width of the key-column.
    """
    def key_column_width(kv: Tuple[str, Any]) -> int:
        key = kv[0]
        value = kv[1]
        width = indent + len(key)
        if isinstance(value, dict):
            return max(
                max_key_column_width(value, indent + 2),
                width)
        return width
    return max(map(key_column_width, fc.iteritems(dictionary)))
