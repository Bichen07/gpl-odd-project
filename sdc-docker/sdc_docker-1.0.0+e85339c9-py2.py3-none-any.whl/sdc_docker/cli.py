"""
Entry points of sdc-docker's command-line interface.
"""

from sdc_docker import container, image, remote_roslaunch
from sdc_docker.io_impl import make_io

def build_image() -> None:
    """
    Entry point of sdc-docker-build-image.

    Perform building of sdc-docker image.
    """
    io = make_io()
    image.build(io)

def update_image() -> None:
    """
    Entry point of sdc-docker-update-image.

    Perform updating of sdc-docker image.
    """
    io = make_io()
    image.update(io)

def start_container() -> None:
    """
    Entry point of sdc-docker-start-container.

    Start sdc-docker container.
    """
    io = make_io()
    container.start(io)

def stop_container() -> None:
    """
    Entry point of sdc-docker-stop-container command-line.

    Stop sdc-docker container.
    """
    io = make_io()
    container.stop(io)

def enter_container_shell() -> None:
    """
    Entry point of sdc-docker-enter-container-shell.

    Enter shell session inside running sdc-docker container.
    """
    io = make_io()
    container.enter_shell(io)

def remote_roslaunch_env_loader() -> None:
    """
    Entry point of sdc-docker-remote-roslaunch-env-loader. Helper utility
    for launching remote ROS nodes inside sdc-docker container.

    roslaunch uses a command specified by the "env-loader" attribute of
    the <machine> tag to run nodes on remote machines. Here is the outline
    of the procedure performed by roslaunch:
    * ssh into the remote machine
    * run env-loader command
    * env-loader command starts a roslaunch-server on the remote machine
    * roslaunch-server starts all remote nodes
    Command for starting remote roslaunch-server is passed into
    the env-loader command as a command-line argument.

    sdc-docker-remote-roslaunch-env-loader can be specified as
    the env-loader command. It shall start a remote container, if it isn't
    running yet, and run the remote roslaunch-server command inside
    the remote container.
    """
    io = make_io()
    remote_roslaunch.env_loader_in_login_shell(io)
