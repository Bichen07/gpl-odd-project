"""
Routines for building sdc-docker stage-1 image.
"""

import dataclasses as dc
from subprocess import PIPE
from typing import List

from funcy import compose, partial, re_find # type: ignore
from pyrsistent import freeze
from pyrsistent.typing import PMap as PMapType
from sdc_docker import config
from sdc_docker.io_impl import Io
from sdc_docker.report import report_dict
from sdc_docker import stages
from sdc_docker.utils import zero_one_from_bool

@dc.dataclass(frozen=True)
class BuildFacts:
    """
    Set of values required for building stage-1.

    Attributes:
        config: sdc-docker configuration
        docker_build_directory: path to directory containing Dockerfile
        extra_args: extra arguments to be passed to `docker build` command
        timezone: timezone to be used inside container
    """
    config: config.Config
    docker_build_directory: str
    extra_args: List[str]
    timezone: str

#*************************************************************************
# I/O functions
# Functions that produce side effects
#*************************************************************************

def build(io: Io, extra_args: List[str]) -> None:
    """
    Build stage-1 image.

    Args:
        io: implementation of low-level I/O functions.
        extra_args: extra arguments to be passed to `docker build` command.
    """
    facts = BuildFacts(
        config=config.read(io),
        docker_build_directory=docker_build_directory(io),
        extra_args=extra_args,
        timezone=get_timezone(io),
    )
    io.log(f"Facts:\n{report_dict(dc.asdict(facts), indent=2)}")
    stages.docker_build_from_template(io,
        build_args=docker_build_args(facts),
        build_directory=facts.docker_build_directory,
        extra_args=extra_args,
        tag=facts.config.stage1_image,
        context={ "facts": dc.asdict(facts) },
    )

def pull(io: Io) -> None:
    """
    Pull stage-1 image from a docker repository.

    Args:
        io: implementation of low-level I/O functions.
    """
    cfg = config.read(io)
    io.subprocess_run("docker pull sdcdoc/sdc-stage-1",
        check=True, shell=True)
    io.subprocess_run(f"docker tag sdcdoc/sdc-stage-1 {cfg.stage1_image}",
        check=True, shell=True)

def download_over_ssh(
        io: Io,
        ssh_upn: str,
        image_name: str) -> None:
    """
    Download stage-1 image through SSH.

    Args:
        io: implementation of low-level I/O functions.
        ssh_upn: user@host string to be used for connecting to SSH server.
        image_name: image name to be used for tagging the downloaded image.
    """
    docker_load_stdout = io.subprocess_run(
        f"ssh {ssh_upn} docker save {image_name} | docker load",
        check=True, shell=True, stdout=PIPE).stdout
    io.subprocess_run("docker tag "
        f"{loaded_image_name(docker_load_stdout)} "
        f"{image_name}",
        check=True, shell=True)

def load_from_file(io: Io, path: str) -> None:
    """
    Load stage-1 image from a file.

    Args:
        io: implementation of low-level I/O functions.
        path: path to the file containing the image.
    """
    cfg = config.read(io)
    docker_load_stdout = io.subprocess_run(
        f"docker load --input {path}",
        check=True, shell=True, stdout=PIPE).stdout
    io.subprocess_run("docker tag "
        f"{loaded_image_name(docker_load_stdout)} "
        f"{cfg.stage1_image}",
        check=True, shell=True)

def docker_build_directory(io: Io) -> str:
    """
    Retrieve path to the directory containing Dockerfile of stage-1 image.

    Args:
        io: implementation of low-level I/O functions.

    Returns:
        Path to the directory containgin Dockerfile of stage-1 image.
    """
    return io.resource_filename("sdc_docker", "data/docker/stage-1")

def get_timezone(io: Io) -> str:
    """
    Retrieve host's timezone information.

    Args:
        io: implementation of low-level I/O functions.

    Returns:
        Timezone information.
    """
    content = io.read_file("/etc/timezone")
    return content.splitlines()[0]

#*************************************************************************
# Pure functions
# Functions that don't have side effects
#*************************************************************************

def docker_build_args(facts: BuildFacts) -> PMapType[str, str]:
    """
    Dictionary of build-time variables (passed as --build-arg
    to `docker build`).

    Args:
        facts: facts used for building stage-1 image.

    Returns:
        Dictionary of build-time variables.
    """
    return freeze({
        "SDC_DOCKER_BUILDING_GIT_ENABLED":
            zero_one_from_bool(facts.config.building_git_enabled),
        "SDC_DOCKER_SSL_VERIFICATION_ENABLED":
            zero_one_from_bool(facts.config.ssl_verification_enabled),
        "SDC_DOCKER_MIRROR_SELECTION_ENABLED":
            zero_one_from_bool(facts.config.mirror_selection_enabled),
        "SDC_DOCKER_UBUNTU_VERSION": facts.config.ubuntu_version,
        "SDC_ROS1_VERSION":
            stages.ros1_version(facts.config.ubuntu_version),
        "TIMEZONE": facts.timezone,
    })

def loaded_image_name(docker_load_stdout: bytes) -> str:
    """
    Extract image name from the output of `docker load` command.

    Args:
        docker_load_stdout: output of `docker load` command.

    Returns:
        Image name.
    """
    return compose(
        partial(re_find, "Loaded image: +(.+) *$"),
        lambda x: x[-2],
        lambda x: x.split("\n"),
        lambda x: x.decode("utf-8")
    )(docker_load_stdout)
