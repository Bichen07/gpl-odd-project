"""
Routines for building sdc-docker stage-2 image.
"""

import dataclasses as dc
from typing import List

from pyrsistent import freeze
from pyrsistent.typing import PMap as PMapType
from sdc_docker import config, stages
from sdc_docker.io_impl import Io
from sdc_docker.report import report_dict

@dc.dataclass(frozen=True)
class BuildFacts:
    """
    Set of values required for building stage-2

    Attributes:
        config: sdc-docker configuration
        docker_build_directory: path to directory containing Dockerfile
        extra_args: extra arguments to be passed to `docker build` command
        host_user_gid: GID of the host user that is going to use sdc-docker
        host_user_uid: UID of the host user that is boing to use sdc-docker
    """
    config: config.Config
    docker_build_directory: str
    extra_args: List[str]
    host_user_gid: int
    host_user_uid: int

#*************************************************************************
# I/O functions
# Functions that produce side effects
#*************************************************************************

def build(io: Io, extra_args: List[str]) -> None:
    """
    Build sdc-docker stage-2 image

    Args:
        io: implementation of low-level I/O functions
        extra_args: extra arguments to be passed to `docker build` command
    """
    facts = BuildFacts(
        config=config.read(io),
        docker_build_directory=docker_build_directory(io),
        extra_args=extra_args,
        host_user_gid=io.getgid(),
        host_user_uid=io.getuid(),
    )
    io.log(f"Facts:\n{report_dict(dc.asdict(facts), indent=2)}")
    stages.docker_build(io,
        build_args=docker_build_args(facts),
        build_directory=facts.docker_build_directory,
        extra_args=extra_args,
        tag=facts.config.stage2_image
    )

def docker_build_directory(io: Io) -> str:
    """
    Retrieve path to the directory containing stage-2 Dockerfile

    Args:
        io: implementation of low-level I/O functions

    Returns:
        Path to the directory
    """
    return io.resource_filename("sdc_docker", "data/docker/stage-2")

#*************************************************************************
# Pure functions
# Functions that don't have side effects
#*************************************************************************

def docker_build_args(facts: BuildFacts) -> PMapType[str, str]:
    """
    Dictionary of build-time variables (passed as --build-arg
    to `docker build`).

    Args:
        facts: facts used for building stage-2 image.

    Returns:
        Dictionary of build-time variables.
    """
    return freeze({
        "SDC_DOCKER_CONTAINER_USER": container_user(),
        "SDC_DOCKER_HOST_USER_GID": str(facts.host_user_gid),
        "SDC_DOCKER_HOST_USER_UID": str(facts.host_user_uid),
        "SDC_DOCKER_STAGE1_IMAGE": facts.config.stage1_image,
        "SDC_ROS1_VERSION":
            stages.ros1_version(facts.config.ubuntu_version),
    })

def container_user() -> str:
    """
    Name of the in-container user.

    Default in-container user is root, which isn't convenient, because it
    will make all files generated inside container to be owned by root,
    even if the files reside on the host's mounts. Thus, we need to create
    an extra user inside container with UID and GID same as the host's user.
    """
    return "user"
