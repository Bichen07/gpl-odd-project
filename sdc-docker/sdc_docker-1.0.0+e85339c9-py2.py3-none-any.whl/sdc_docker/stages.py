"""
Common routines for building sdc-docker stages.
"""
from typing import List, Mapping

from funcy import mapcat, iteritems # type: ignore
from sdc_docker.io_impl import Io
from sdc_docker.utils import temporary_directory

def docker_build(
        io: Io,
        build_args: Mapping[str, str],
        build_directory: str,
        extra_args: List[str],
        tag: str) -> None:
    """
    Invoke `docker build` command.

    Args:
        io: implementation of low-level I/O functions
        build_args: docker build-time variables
        build_directory: path to directory containing Dockerfile
        extra_args: extra arguments to be passed to `docker build` command
        tag: name of the built docker image
    """
    make_build_arg = lambda x: ["--build-arg", f"{x[0]}={x[1]}"]
    io.subprocess_run(
        ["docker", "build"] + \
        list(mapcat(make_build_arg, iteritems(build_args))) + \
        extra_args + \
        ["--tag", tag] + \
        [build_directory],
        check=True)

def ros1_version(ubuntu_version: str) -> str:
    """
    Decide which ROS 1 version to use based on the version of Ubuntu.
    """
    return {
        "xenial": "kinetic",
        "bionic": "melodic",
    }[ubuntu_version]

def docker_build_from_template( # pylint: disable=too-many-arguments
        io: Io,
        build_args: Mapping[str, str],
        build_directory: str,
        extra_args: List[str],
        tag: str,
        context: Mapping) -> None:
    """ Invoke `docker_build`, but as the Dockerfile use a file generated from
    Dockerfile.jinja template file. """
    with temporary_directory(io, prefix="sdc-docker-") as temp_dir:
        io.log(f"Creating temporary context {temp_dir} ...")
        io.copytree(
            build_directory, str(temp_dir), symlinks=True, dirs_exist_ok=True)
        dockerfile = io.render_jinja_template(
            "Dockerfile.jinja", searchpath=str(temp_dir), context=context)
        io.write_file(f"{temp_dir}/Dockerfile", dockerfile)
        docker_build(io, build_args, str(temp_dir), extra_args, tag)
