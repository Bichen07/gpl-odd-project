"""
Reading sdc-docker configuration.
"""

import dataclasses as dc
from pyrsistent import freeze
from pyrsistent.typing import PVector as PVectorType
from sdc_docker.io_impl import Io
from sdc_docker.utils import bool_from_string

@dc.dataclass(frozen=True)
class Config:
    """
    Internal representation of sdc-docker configuration.

    Attributes:
        audio_enabled: support audio inside container.
        building_git_enabled: build Git inside docker image.
        container_command: specifies executable to run when the container
            starts.
        container_name: name of the sdc-docker container to be spawned.
        container_working_directory: working directory to be used inside
            container.
        detached_mode_enabled: whether we run container in foregraound or
            in detached mode.
        graphics_enabled: support GUI inside container.
        image: image to be used for spawning sdc-docker container.
        mirror_selection_enabled: enable selection of Ubuntu mirrors
            to be used for building sdc-docker image.
        nvidia_support_enabled: support Nvidia GPUs inside container.
        ssl_verification_enabled: enable SSL verification
        stage1_image: stage-1 image will be tagged with this name, after
            it is being built or updated.
        stage2_image: stage-2 image will be tagged with this name, after
            it is being built or updated.
        ubuntu_version: specifies the base image to be used for building
            sdc-docker image.
        user_options: extra options to be passed to `docker run` command
            when starting sdc-docker container.
        user_volumes: extra mounted to be added to sdc-docker container.
        vaapi_enabled: support VAAPI inside contianer.
    """
    audio_enabled: bool
    building_git_enabled: bool
    container_command: str
    container_name: str
    container_working_directory: str
    detached_mode_enabled: bool
    graphics_enabled: bool
    image: str
    mirror_selection_enabled: bool
    nvidia_support_enabled: bool
    ssl_verification_enabled: bool
    stage1_image: str
    stage2_image: str
    ubuntu_version: str
    user_options: str
    user_volumes: PVectorType[str]
    vaapi_enabled: bool

def read(io: Io) -> Config:
    """
    Read sdc-docker configuration from environment variables.

    Args:
        io: implementation of low-level I/O functions.

    Returns:
        Configuration object.
    """
    ubuntu_version = environ_with_default(
        io, "SDC_DOCKER_UBUNTU_VERSION", "bionic")
    return Config(
        audio_enabled=bool_from_string(
            environ_with_default(io, "SDC_DOCKER_AUDIO_ENABLED", "true")),
        building_git_enabled=bool_from_string(
            environ_with_default(
                io, "SDC_DOCKER_BUILDING_GIT_ENABLED", "false")),
        container_command=environ_with_default(
            io, "SDC_DOCKER_CONTAINER_COMMAND",
            "/usr/local/sdc-docker/bin/infinite-loop"),
        container_name=environ_with_default(
            io, "SDC_DOCKER_CONTAINER_NAME", f"sdc-{ubuntu_version}"),
        container_working_directory=environ_with_default(
            io, "SDC_DOCKER_CONTAINER_WORKING_DIRECTORY", "/home/user"),
        detached_mode_enabled=bool_from_string(environ_with_default(
            io, "SDC_DOCKER_DETACHED_MODE_ENABLED", "true")),
        graphics_enabled=bool_from_string(
            environ_with_default(
                io, "SDC_DOCKER_GRAPHICS_ENABLED", "true")),
        image=environ_with_default(
            io, "SDC_DOCKER_IMAGE", f"sdc-stage-2:{ubuntu_version}"),
        mirror_selection_enabled=bool_from_string(
            environ_with_default(
                io, "SDC_DOCKER_MIRROR_SELECTION_ENABLED", "false")),
        nvidia_support_enabled=bool_from_string(
            environ_with_default(
                io, "SDC_DOCKER_NVIDIA_SUPPORT_ENABLED", "true")),
        ssl_verification_enabled=bool_from_string(
            environ_with_default(
                io, "SDC_DOCKER_SSL_VERIFICATION_ENABLED", "true")),
        stage1_image=environ_with_default(
            io, "SDC_DOCKER_STAGE1_IMAGE",
            f"sdc-stage-1:{ubuntu_version}"),
        stage2_image=environ_with_default(
            io, "SDC_DOCKER_STAGE2_IMAGE",
            f"sdc-stage-2:{ubuntu_version}"),
        ubuntu_version=ubuntu_version,
        user_options=parse_user_options(
            environ_with_default(io, "SDC_DOCKER_USER_OPTIONS", "")),
        user_volumes=parse_user_volumes(
            environ_with_default(io, "SDC_DOCKER_USER_VOLUMES", "")),
        vaapi_enabled=bool_from_string(
            environ_with_default(io, "SDC_DOCKER_VAAPI_ENABLED", "true")),
    )

def parse_user_options(text: str) -> str:
    """
    Produce internal representation of user options. Remove unnecessary
    whitespaces.

    Args:
        text: raw user options, read from an environment variable.

    Returns:
        Internal representation of user options.
    """
    return " ".join(text.split())

def parse_user_volumes(text: str) -> PVectorType[str]:
    """
    Produce internal representation of user volumes' specifications. Remove
    whitespaces and construct a list of specifications.

    Args:
        text: raw user volumes' specifications, read from environment.

    Returns:
        Immutable list of volume specifications.
    """
    return freeze(text.split())

def environ_with_default(io: Io, name: str, default: str) -> str:
    """
    Read environment variable. Return default value, if the environment
    variable doesn't exist.

    Args:
        io: implementation of low-level I/O functions.
        name: name of the environment variable to be read.
        default: value to be returned, if environment variables doesn't exist.

    Returns:
        Value of the environment variable.
    """
    try:
        return io.getenv(name)
    except KeyError:
        return default
