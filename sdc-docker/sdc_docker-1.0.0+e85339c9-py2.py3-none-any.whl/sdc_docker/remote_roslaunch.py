"""
Routines for launching remote ROS nodes inside sdc-docker container.
"""

from argparse import ArgumentParser, REMAINDER
from subprocess import PIPE
from typing import List

from funcy import none # type: ignore
from sdc_docker import config, container
from sdc_docker.io_impl import Io

def env_loader_in_login_shell(io: Io) -> None:
    """
    Run env_loader inside a login shell.

    On remote machines, SDC_DOCKER_* environment variables defined inside
    ~/.profile file. When roslaunch ssh into a remote machine, by default
    it doesn't read the ~/.profile file, thus we must run the env-loader
    command inside a login shell, by running `bash -l` and passing it
    the env-loader command as a command-line parameter.

    Args:
        io: implementation of I/O
    """
    parser = ArgumentParser()
    parser.add_argument(
        "remaining",
        nargs=REMAINDER,
        type=str,
        help="Remaining arguments passed to env-loader")
    args = io.parse_arguments(parser)
    arguments = " ".join(args.remaining)

    io.putenv(args_var_name(), arguments)
    run_script_in_login_shell(io,
        "from sdc_docker.io_impl import make_io; "
        "import sdc_docker.remote_roslaunch as rr; "
        "io = make_io(); "
        "rr.env_loader(io)")

def env_loader(io: Io) -> None:
    """
    Start sdc-docker container, if it isn't running, and run
    the roslaunch-server command inside the container.

    Args:
        io: implementation of I/O
    """
    cfg = config.read(io)

    def is_sdc_container(name: str) -> bool:
        return name == cfg.container_name
    if none(is_sdc_container, get_existing_containers(io)):
        container.start(io)

    arguments = io.getenv(args_var_name())
    run_arguments_inside_container(io, cfg.container_name, arguments)

def run_script_in_login_shell(
        io: Io,
        script: str) -> None:
    """
    Run an arbitrary python script inside a login shell.

    Args:
        io: implementation of I/O
        script: script to be ran inside the login shell
    """
    io.subprocess_run(f"bash -lc \"{io.sys_executable()} -c '{script}'\"",
        shell=True, check=True)

def get_existing_containers(io: Io) -> List[str]:
    """
    List all existing docker containers on current machine.

    Args:
        io: implementation of I/O

    Returns:
        List of names of existing containers.
    """
    return io.subprocess_run(
        "docker ps --all --format='{{.Names}}'",
        stdout=PIPE, shell=True, check=True) \
            .stdout \
            .decode("utf-8") \
            .split()

def run_arguments_inside_container(
        io: Io,
        container_name: str,
        arguments: str) -> None:
    """
    Run an arbitrary command inside a docker container.

    Args:
        io: implementation of I/O
        container_name: name of the container to run the command in
        arguments: shell command to run inside the container
    """
    io.subprocess_run(
        "docker exec "
        f"{container_name} "
        f"bash -c \"source devel/setup.bash; {arguments}\"",
        shell=True, check=True)

def args_var_name() -> str:
    """
    Name of the environment variable that is used for passing roslaunch-server
    command into env_loader function.

    `env_loader_in_login_shell` reads the roslaunch-server command from
    command-line and writes this environment variable. `env_loader`, in turn,
    reads the value of this variable and use it to start roslaunch-server
    inside container.

    The reason why we pass the command through an environment variable is
    that the roslaunch-server command might be very complex and, thus might
    require compilcated escaping.
    """
    return "__SDC_ENV_LOADER_ARGS"
