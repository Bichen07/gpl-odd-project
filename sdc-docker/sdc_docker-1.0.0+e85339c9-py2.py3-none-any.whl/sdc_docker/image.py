"""
Routines for managing sdc-docker image.
"""

from argparse import ArgumentParser, REMAINDER
from sdc_docker import config, stage1, stage2
from sdc_docker.io_impl import Io

def build(io: Io) -> None:
    """
    Build sdc-docker image. First, build stage-1 and then build stage-2.

    Args:
        io: implementation of low-level I/O functions.

    Raises:
        RuntimeError: if `data/docker` doesn't exist
    """
    parser = ArgumentParser()
    parser.add_argument(
        "extra_args",
        nargs=REMAINDER,
        type=str,
        help="Extra arguments passed to 'docker build' command")
    args = io.parse_arguments(parser)

    if not io.file_exists(
            io.resource_filename("sdc_docker", "data/docker")):
        raise RuntimeError("`data/docker` directory doesn't exist. "
                "Please make sure that sdc-docker package is installed in "
                "development mode.")

    io.log("Building stage-1 ...")
    stage1.build(io, args.extra_args[1:])
    io.log("Building stage-2 ...")
    stage2.build(io, args.extra_args[1:])

def update(io: Io) -> None:
    """
    Update sdc-docker image: obtain stage-1 and then build stage-2.

    Args:
        io: implementation of low-level I/O functions.
    """
    parser = ArgumentParser()
    parser.add_argument(
        "--stage1-from-file",
        type=str,
        help="Load stage-1 image from the file specified after this flag")
    parser.add_argument(
        "--stage1-from-ssh",
        type=str,
        help="Load stage-1 image over SSH from a remote computer using "
            "user@address provided after the flag")
    args = io.parse_arguments(parser)
    loading_stage1_from_file = args.stage1_from_file is not None
    downloading_stage1_over_ssh = args.stage1_from_ssh is not None
    if loading_stage1_from_file:
        io.log(f"Loading stage-1 from file: {args.stage1_from_file}")
        image_file = args.stage1_from_file
        stage1.load_from_file(io, image_file)
    elif downloading_stage1_over_ssh:
        ssh_upn = args.stage1_from_ssh
        cfg = config.read(io)
        io.log(f"Downloading stage-1 over SSH: {ssh_upn}")
        stage1.download_over_ssh(io, ssh_upn, cfg.stage1_image)
    else:
        io.log("Pulling stage-1 ...")
        stage1.pull(io)
    io.log("Building stage-2 ...")
    stage2.build(io, extra_args=[])
