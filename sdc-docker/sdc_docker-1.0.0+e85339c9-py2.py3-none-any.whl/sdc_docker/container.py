"""
Routines for managing life-cycle of sdc-docker container.
"""

from contextlib import contextmanager
import dataclasses as dc
import os.path
from string import hexdigits
from subprocess import PIPE
import traceback
from typing import Any, Iterator, List, Optional, Tuple, Sequence

from funcy import compose, mapcat, partial, re_find # type: ignore
from funcy import re_tester, remove
from pyrsistent import freeze, thaw
from pyrsistent.typing import PMap as PMapType
from pyrsistent.typing import PVector as PVectorType
from sdc_docker import config
from sdc_docker.io_impl import Io
from sdc_docker.report import report_dict
from sdc_docker.stage2 import container_user
from sdc_docker.utils import find_files, with_nothing

Option = Tuple[str, Optional[str]]
Options = PVectorType[Option]

@dc.dataclass(frozen=True)
class Facts():
    """
    Facts required for running sdc-docker container.
    """
    config: config.Config
    has_nvidia_modeset: bool
    host_home: str
    libnvcuvid_path: str
    nvidia_driver_directory: str

#*************************************************************************
# I/O functions
# Functions that produce side effects
#*************************************************************************

def start(io: Io) -> None:
    """
    Start sdc-docker container.

    Args:
        io: implementation of low-level I/O functions.
    """
    prepare_bash_history(io)
    run(io, **start_container_params())

def stop(io: Io) -> None:
    """
    Stop sdc-docker container.

    Args:
        io: implementation of low-level I/O functions.
    """
    facts = gather_facts(io)
    docker_stop(io, facts.config.container_name)

def enter_shell(io: Io) -> None:
    """
    Enter shell inside running sdc-docker container.

    Args:
        io: implementation of low-level I/O functions.
    """
    facts = gather_facts(io)
    io.subprocess_run(enter_shell_command(facts), shell=True, check=True)

def run(io: Io, extra_options: Options) -> None:
    """
    Perform `docker run` command to start sdc-docker container.

    Args:
        io: implementation of low-level I/O functions.
        extra_options: extra options to be passed to `docker run` command.
    """
    facts = gather_facts(io)
    all_options = options(docker_options(facts), extra_options)

    io.log("Facts:")
    io.log(report_dict(dc.asdict(facts), indent=2))
    io.log("Docker options:")
    io.log(indent(2, report_docker_options(all_options)))

    with audio_configured(io) \
            if facts.config.audio_enabled else with_nothing():
        docker_run(io,
            opts=all_options,
            user_opts=facts.config.user_options,
            image_name=facts.config.image,
            command=facts.config.container_command)

    check_revision(io, facts.config.ssl_verification_enabled)

def gather_facts(io: Io) -> Facts:
    """
    Gather facts required for running sdc-docker container.

    Args:
        io: implementation of low-level I/O functions.

    Returns:
        Gathered facts.
    """
    cfg = config.read(io)
    return Facts(
        config=cfg,
        has_nvidia_modeset=io.file_exists("/dev/nvidia-modeset")
            if cfg.nvidia_support_enabled else False,
        host_home=io.getenv("HOME"),
        libnvcuvid_path=find_libnvcuvid(io)
            if cfg.nvidia_support_enabled else "",
        nvidia_driver_directory=find_nvidia_driver_directory(io)
            if cfg.nvidia_support_enabled else "",
    )

@contextmanager
def audio_configured(io: Io) -> Iterator[None]:
    """
    Context manager that brings up and releases audio-related resources.

    Args:
        io: implementation of low-level I/O functions.

    Yields:
        None: when initialization of audio resources finished.
    """
    module_id = load_pulseaudio_module(io)
    configure_pulseaudio(io)
    try:
        yield
    finally:
        unload_pulseaudio_module(io, module_id)
        release_pulseaudio(io)

def load_pulseaudio_module(io: Io) -> int:
    """
    Initialize pulseaudio for working with sdc-docker.

    Args:
        io: implementation of low-level I/O functions.

    Returns:
        ID of the loaded pulseaudio module. Need to know it when unloading
        the module.
    """
    result = io.subprocess_run(["pactl",
        "load-module",
        "module-native-protocol-unix",
        f"socket={pulseaudio_socket_path()}"], stdout=PIPE, check=True)
    module_id = int(result.stdout.decode("utf-8"))
    return module_id

def unload_pulseaudio_module(io: Io, module_id: int) -> None:
    """
    Unload pulseaudio module by ID.

    Args:
        io: implementation of low-level I/O functions.
        module_id: ID of the module that requires to be unloaded.
    """
    io.subprocess_run(
        ["pactl", "unload-module", str(module_id)], check=True)

def configure_pulseaudio(io: Io) -> None:
    """
    Create pulseaudio client configuration.

    Args:
        io: implementation of low-level I/O functions.
    """
    io.write_file(pulseaudio_client_conf_path(),
        f"default-server = unix:{pulseaudio_socket_path()}\n"
        "autospawn = no\n"
        "daemon-binary = /bin/true\n"
        "enable-shm = false\n")

def release_pulseaudio(io: Io) -> None:
    """
    Release pulseaudio client configuration.

    Args:
        io: implementation of low-level I/O functions.
    """
    io.subprocess_run(
        ["rm", pulseaudio_client_conf_path()],
        check=True)

def docker_run(
        io: Io,
        opts: Options,
        user_opts: str,
        image_name: str,
        command: str) -> None:
    """
    Invoke `docker run` command.

    Args:
        io: implementation of low-level I/O functions.
        opts: list of options to be passed to `docker run`.
        user_opts: string of extra options to be passed to `docker run`.
        image_name: use this image for spawning a new container.
        command: execute this command inside container.
    """
    command_line_opts = " ".join(command_line_docker_options(opts))
    io.subprocess_run(
        "docker run "
        f"{command_line_opts} "
        f"{user_opts} "
        f"{image_name} "
        f"{command}",
        shell=True, check=True)

def docker_stop(io: Io, container_name: str) -> None:
    """
    Invoke `docker stop`

    Args:
        io: implementation of low-level I/O functions.
        container_name: name of the container to be stopped.
    """
    io.subprocess_run(
        f"docker stop {container_name}", shell=True, check=True)

def get_nvidia_driver_version(io: Io) -> PMapType[str, int]:
    """
    Figure out version of the installed nvidia driver.

    Args:
        io: implementation of low-level I/O functions.

    Returns:
        Version of the nvidia driver in the for of dictionary:
        {
            "major": ...
            "minor": ...
            "patch": ...
        }

    Raises:
        RuntimeError: when failed to retrieve the driver's version
    """
    try:
        stdout = io.subprocess_run(["nvidia-smi", "--query"],
            stdout=PIPE, check=True).stdout.decode("utf-8").split("\n")
        version_line: str = \
            list(filter(re_tester("Driver Version"), stdout))[0]
        version_tuple = re_find(r"(\d+).(\d+).(\d+)", version_line)
        return freeze({
            "major": version_tuple[0],
            "minor": version_tuple[1],
            "patch": version_tuple[2]
        })
    except Exception as exc: # pragma: no cover
        message = "Failed to retrieve nvidia driver version"
        raise RuntimeError(message) from exc

def find_nvidia_driver_directory(io: Io) -> str:
    """
    Figure out installation directory of the nvidia drivers.

    Args:
        io: implementation of low-level I/O functions.

    Returns:
        Path to the directory.

    Raises:
        RuntimeError: when failed to find the driver's directory
    """
    try:
        driver_version = get_nvidia_driver_version(io)
        find = compose(
            list,
            partial(remove, re_tester("i386")),
            partial(find_files, io))
        paths = find(
            "/usr/lib",
            f"libGLX_nvidia.so.{driver_version.major}*")
        return os.path.dirname(paths[0])
    except Exception as exc: # pragma: no cover
        message = "Failed to find nvidia driver directory"
        raise RuntimeError(message) from exc

def find_libnvcuvid(io: Io) -> str:
    """
    Figure out path to the libnvcuvid.so library.

    Args:
        io: implementation of low-level I/O functions.

    Returns:
        Path to the library.

    Raises:
        RuntimeError: when failed to find the library.
    """
    try:
        driver_version = get_nvidia_driver_version(io)
        find = compose(
            list,
            partial(remove, re_tester("i386")),
            partial(find_files, io))
        paths = find("/usr/lib", f"*nvcuvid.so.{driver_version.major}*")
        return paths[0]
    except Exception as exc: # pragma: no cover
        raise RuntimeError("Failed to find libnvcuvid.so") from exc

def check_revision(io: Io, ssl_verification: bool) -> None:
    """
    Check revision of the current installation of the sdc-docker package.
    Display warning if the version is out of date.

    Args:
        io: implementation of low-level I/O functions.
        ssl_verification: whether we check SSL certificates,
            when accessing Internet
    """
    try:
        package_version = io.version("sdc_docker")
        local_revision = local_version_identifier(package_version)
        assert valid_revision(local_revision)
        check_certificate_flag = "--no-check-certificate" \
            if not ssl_verification else ""
        remote_revision = io.subprocess_run(
            f"wget "
                "--quiet "
                f"{check_certificate_flag} "
                "--output-document - "
                f"{remote_revision_url()}",
            shell=True, stdout=PIPE, check=True) \
            .stdout \
            .decode("utf-8") \
            .split("\n")[0][:8]
        assert valid_revision(remote_revision)
        if local_revision != remote_revision:
            io.log(revision_mismatch_message(remote_revision))
    except Exception: # pylint: disable=broad-except
        io.log(revision_checking_failure_message(traceback.format_exc()))

def prepare_bash_history(io: Io) -> None:
    """
    Create bash history file to be mounted into container. Allows saving
    bash history between docker sessions.
    """
    history_path = os.path.join(io.getenv("HOME"), bash_history_file())
    if not io.file_exists(history_path):
        io.log(f"Creating {history_path}")
        io.write_file(history_path, "")

#*************************************************************************
# Pure functions
# Functions that don't have side effects
#*************************************************************************

def report_docker_options(opts: Options) -> str:
    """
    Generate a pretty-printed version of docker's options.

    Args:
        opts: list of options to be reported

    Returns:
        String representing pretty-printed version of the options.
    """
    option_names = set(map(lambda o: o[0], opts))
    max_option_name_length = max(map(len, option_names))
    def line(opt: Option) -> str:
        name = opt[0]
        value = opt[1]
        padded_name = f"{name}".ljust(max_option_name_length)
        expanded_value = f"{value}" if value is not None else ""
        return f"--{padded_name} {expanded_value}"
    return "\n".join(sorted(map(line, opts)))

def indent(spaces: int, text: str) -> str:
    """
    Indent a text.

    Args:
        spaces: number of spaces to indent with
        text: text to be indented

    Returns:
        Indented text.
    """
    def indent_line(l: str) -> str:
        return " " * spaces + l
    lines = text.split("\n")
    return "\n".join(map(indent_line, lines))

def docker_options(facts: Facts) -> Options:
    """
    Figure out `docker run` options based on the facts.

    Args:
        facts: facts required for running sdc-docker container

    Returns:
        List of options.
    """
    return options(
        apparmor_unconfined_option(),
        audio_options() if facts.config.audio_enabled else empty_option(),
        container_name_option(facts.config.container_name),
        container_user_option(),
        container_working_directory_option(
            facts.config.container_working_directory),
        detached_mode_option()
            if facts.config.detached_mode_enabled else empty_option(),
        graphics_options()
            if facts.config.graphics_enabled else empty_option(),
        mount_host_bash_history(
            facts.host_home,
            os.path.join("/home", container_user())),
        mount_user_volumes_options(facts.config.user_volumes),
        networking_options(facts),
        nvidia_options(facts)
            if facts.config.nvidia_support_enabled else empty_option(),
        remove_container_after_finished_option(),
    )

def command_line_docker_options(opts: Options) -> List[str]:
    """
    Convert `Options` into string representation.

    Args:
        opts: list of options to be converted

    Returns:
        List of stringified options.
    """
    def unfold_option(o: Option) -> List[str]:
        name = o[0]
        value = o[1]
        expanded_name = [f"--{name}"]
        expanded_value = [f"{value}"] if not value is None else []
        return expanded_name + expanded_value
    return freeze(list(mapcat(unfold_option, opts)))

def apparmor_unconfined_option() -> Options:
    """
    Returns list of `docker run` options related to AppArmor.
    """
    # Potential security vulnerability.
    # Disable AppArmor for docker containe, otherwise, Qt applications
    # can't access dbus, when --net=host:
    #    https://github.com/moby/moby/issues/38442
    return option("security-opt", "apparmor:unconfined")

def audio_options() -> Options:
    """
    Returns list of `docker run` options related to audio.
    """
    return options(
        option("device", "/dev/snd"),
        option("env", "PULSE_COOKIE=/tmp/sdc-docker-pulseaudio.cookie"),
        option("env", f"PULSE_SERVER=unix:{pulseaudio_socket_path()}"),
        option("volume",
            f"{pulseaudio_client_conf_path()}:"
            f"{pulseaudio_client_conf_path()}:ro"),
        option("volume",
            f"{pulseaudio_socket_path()}:"
            f"{pulseaudio_socket_path()}"),
    )

def container_name_option(container_name: str) -> Options:
    """
    Returns list of `docker run` options that specify name of the container.
    """
    return option("name", container_name)

def container_user_option() -> Options:
    """
    Returns list of `docker run` options that specify default user
    to be used inside container.
    """
    return option("user", container_user())

def container_working_directory_option(directory: str) -> Options:
    """
    Returns list of `docker run` options that specify default working
    directory to be used inside container.
    """
    return option("workdir", directory)

def detached_mode_option() -> Options:
    """
    Returns list of `docker run` options that starts container
    in detached mode.
    """
    return option("detach", None)

def graphics_options() -> Options:
    """
    Returns list of `docker run` options that enable GUI inside container.
    """
    return options(
        option("env", "DISPLAY"),
        option("volume", "/tmp/.X11-unix:/tmp/.X11-unix"),
    )

def mount_host_bash_history(host_home: str, cont_home: str) -> Options:
    """
    Returns list of `docker run` options that mount the host's
    ~/.bash_history file into container.
    """
    return option("volume",
        f"{host_home}/{bash_history_file()}:"
        f"{cont_home}/.bash_history:rw")

def mount_user_volumes_options(user_volumes: Sequence[str]) -> Options:
    """
    Returns list of `docker run` options that adds a list of arbitrary
    mounts to the container.

    Args:
        user_volumes: list of mounts to be added to the container.

    Returns:
        List of options.
    """
    def to_option(v: str) -> Options:
        return option("volume", v)
    return options(*map(to_option, user_volumes))

def networking_options(facts: Facts) -> Options:
    """
    Returns list of `docker run` options related to networking.
    """
    return options(
        option("cap-add", "NET_ADMIN"),
        option("network", "host"),
        option("volume",
            f"{facts.host_home}/.ssh:{container_home()}/.ssh:ro"),
    )

def nvidia_options(facts: Facts) -> Options:
    """
    Returns list of `docker run` options enabling Nvidia support inside
    container.
    """
    return options(
        option("device", "/dev/nvidia-modeset")
            if facts.has_nvidia_modeset else empty_option(),
        option("volume",
            f"{facts.nvidia_driver_directory}/vdpau:"
            "/usr/lib/x86_64-linux-gnu/vdpau:ro") \
                if facts.config.vaapi_enabled else empty_option(),
        option("env", "NVIDIA_VISIBLE_DEVICES=all"),
        option("env",
            "NVIDIA_DRIVER_CAPABILITIES=compute,graphics,utility"),
        option("gpus", "all"),
        option("volume",
            f"{facts.libnvcuvid_path}:/usr/lib/libnvcuvid.so:ro"),
        mount_option("bind",
            f"{facts.nvidia_driver_directory}/libnvidia-encode.so",
            "/usr/lib/x86_64-linux-gnu/libnvidia-encode.so",
            readonly=True),
    )

def remove_container_after_finished_option() -> Options:
    """
    Returns list of `docker run` options telling docker to remove
    the container automatically, after it finished.
    """
    return option("rm", None)

def start_container_params() -> PMapType[str, Any]:
    """
    Returns extra options to be passed to `docker run` when starting
    sdc-docker container.
    """
    return freeze({
        "extra_options": [
            ("init", None),
        ],
    })

def enter_shell_command(facts: Facts) -> str:
    """
    Returns a string that represent a docker command required for entering
    a shell session inside sdc-docker container.
    """
    return \
        "docker exec " \
        "--env TERM=xterm-256color " \
        "--interactive " \
        "--tty " \
        f"--user {container_user()} " \
        f"{facts.config.container_name} " \
        "/usr/local/sdc-docker/bin/enter-container-shell"

def empty_option() -> Options:
    """
    Returns an empty list of options. Required for making `Options`
    to be closed under composition.
    """
    return freeze([])

def option(name: str, value: Optional[str]) -> Options:
    """
    Returns a list of options consisting of a single option.

    Args:
        name: name of the option
        value: value of the option

    Returns:
        List of options.
    """
    return freeze([(name, value)])

def options(*args: Options) -> Options:
    """
    Returns a list of options consisting of options passed to the function
    as arguments.
    """
    return freeze(list(mapcat(thaw, args)))

def mount_option(
        mount_type: str,
        source: str,
        destination: str,
        readonly: bool = False) -> Options:
    """
    A helper function for formatting `docker run`'s `--mount` option.
    """
    return option("mount",
        f"type={mount_type}"
        f",src={source}"
        f",dst={destination}"
        f"{',readonly' if readonly else ''}"
    )

def container_home() -> str:
    """
    Path to the home directory of the container's user.
    """
    return os.path.join("/home", container_user())

def pulseaudio_client_conf_path() -> str:
    """
    Path to the pulseaudio client configuration file.
    """
    return "/tmp/sdc-docker-pulseaudio-client.conf"

def pulseaudio_socket_path() -> str:
    """
    Path to the pulseaudio socket.
    """
    return "/tmp/sdc-docker-pulseaudio.socket"

def remote_revision_url() -> str:
    """
    URL of the file that keeps the latest successfully built git revision
    of sdc-docker.
    """
    return "https://dev.mupher.com:20002/nextcloud/index.php/s/" \
        "n3MWSJiLXWCyYtR/download"

def local_version_identifier(version: str) -> str:
    """
    Parse out git revision in the version of the sdc-docker package.
    """
    return re_find(r"\+(.+)$", version)

def valid_revision(revision: str) -> bool:
    """
    Test validity of a git revision.
    """
    return \
        len(revision) <= 40 and \
        all(ch in hexdigits for ch in revision)

def revision_mismatch_message(
        remote_revision: str) -> str: # pragma: no cover
    """
    Returns message to be displayed when the currently installed version
    doesn't match the remote version of the sdc-docker package.
    """
    return f"""
############################################################################

    Version of sdc-docker is out of sync with the server.
    Please perform the following steps:

    * fetch sdc-docker repository
    * checkout revision {remote_revision[:8]}
    * re-install sdc-docker python package
    * update sdc-docker image

############################################################################
"""

def revision_checking_failure_message(tb: str) -> str:
    """
    Returns message to be displayed when version of sdc-docker failed
    to be verified.
    """
    return f"""
############################################################################

    Failed to check revision of sdc-docker due to the following
    exception:

{tb}

############################################################################
"""

def bash_history_file() -> str:
    """
    Name of the host's file for saving container's bash history
    """
    return ".sdc-docker-bash-history"
