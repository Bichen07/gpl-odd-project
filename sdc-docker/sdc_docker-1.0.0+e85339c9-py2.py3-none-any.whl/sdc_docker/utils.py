"""
Assorted utility function.
"""

from contextlib import contextmanager
from pathlib import Path
from subprocess import PIPE
from typing import Any, Iterator

from pyrsistent import pmap, PMap
from sdc_docker.io_impl import Io

def bool_from_string(s: str) -> bool:
    """
    Convert a string into a boolean.

    Returns:
        Boolean value.

    Raises:
        RuntimeError: if string can't be converted.
    """
    if s.lower() in ["true", "yes", "on", "y", "1"]:
        return True
    if s.lower() in ["false", "no", "off", "n", "0"]:
        return False
    raise RuntimeError(f"Can't convert '{s}' into boolean")

def zero_one_from_bool(b: bool) -> str:
    """
    Convert boolean into a string "1" or "0".
    """
    return "1" if b else "0"

def find_files(
        io: Io,
        where: str,
        pattern: str,
        case_sensitive: bool = True) -> list:
    """
    Find files matching a pattern.

    Args:
        io: implementation of low-level I/O functions
        where: path to directory where we search for files
        pattern: pattern, which the files should match to
        case_sensitive: whether pattern matching shoulbe case-sensitive

    Returns:
        List of paths to found files
    """
    stdout = io.subprocess_run(
        ["find", where, "-name" if case_sensitive else "-iname", pattern],
        stdout=PIPE, check=True).stdout
    return list(filter(len, stdout.decode("utf-8").split("\n")))

def pmap_project(m: dict, *args: Any) -> PMap:
    """
    Extract desired keys from a dictionary and return an immutable
    dictionary out of those keys.

    Args:
        m: source dictionary
        *args: keys that should be extracted

    Returns:
        Immutable dictionary with extracted keys
    """
    return pmap({k: m[k] for k in args})

@contextmanager
def with_nothing() -> Iterator[None]:
    """
    Context-manager that does nothing. Comes in handy when needs to return
    a context from an if-else expression.
    """
    yield

def undefined() -> None:
    """
    Raise an exception. Can be used for marking functions that haven't been
    implemented yet.
    """
    raise RuntimeError("Undefined")

@contextmanager
def temporary_directory(io: Io, prefix: str) -> Iterator[Path]:
    """ A context manager that creates a temporary directory and removes
    it on finish. """
    directory = io.mkdtemp(prefix=prefix)
    try:
        yield Path(directory)
    finally:
        io.rmtree(directory)
