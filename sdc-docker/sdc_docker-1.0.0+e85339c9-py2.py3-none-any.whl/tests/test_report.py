"""
Test generation of a textual report
"""

from sdc_docker import report

def test_key_column_width() -> None:
    """
    Test `report.max_key_column_width()`.
    """
    assert report.max_key_column_width({
        "some": None,
        "random": None,
        "words": None,
    }, indent=0) == 6
    assert report.max_key_column_width({
        "some": None,
        "random": None,
        "dict": {
            "nested_key": None,
        },
        "words": None,
    }, indent=0) == 12
    assert report.max_key_column_width({
        "some": None,
        "random": {
            "abcd": None,
        },
        "words": None,
    }, indent=0) == 6

def test_report_dict() -> None:
    """
    Test `report.report_dict()`.
    """
    assert report.report_dict({
        "key": "value",
    }, indent=0) == "key: value"
    assert report.report_dict({
        "key": "value",
    }, indent=3) == "   key: value"
    assert report.report_dict({
        "a": {
            "b": "value"
        },
    }, indent=0) == \
        "a:\n" \
        "  b: value"
    assert report.report_dict({
        "key": {
            "key2": None,
            "key3": {
                "key4": "value",
            },
        },
    }, indent=0) == \
        "key:\n" \
        "  key2:   None\n" \
        "  key3:\n" \
        "    key4: value"
    assert report.report_dict({ "key": [ "1", "2"] }) == \
        "key:\n" \
        "  1\n" \
        "  2"
