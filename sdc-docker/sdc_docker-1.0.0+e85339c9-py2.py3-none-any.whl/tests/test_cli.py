"""
Test `sdc_docker.cli` module.
"""

from unittest.mock import patch, Mock

from sdc_docker import cli

@patch("sdc_docker.image.build")
@patch("sdc_docker.cli.make_io")
def test_build_image(make_io: Mock, build: Mock) -> None:
    """
    Test `cli.build_image()`.
    """
    cli.build_image()
    make_io.assert_called_once()
    build.assert_called_once()

@patch("sdc_docker.image.update")
@patch("sdc_docker.cli.make_io")
def test_update_image(make_io: Mock, update: Mock) -> None:
    """
    Test `cli.update_image()`.
    """
    cli.update_image()
    make_io.assert_called_once()
    update.assert_called_once()

@patch("sdc_docker.container.start")
@patch("sdc_docker.cli.make_io")
def test_start_container(make_io: Mock, start: Mock) -> None:
    """
    Test `cli.start_container()`.
    """
    cli.start_container()
    make_io.assert_called_once()
    start.assert_called_once()

@patch("sdc_docker.container.stop")
@patch("sdc_docker.cli.make_io")
def test_stop_container(make_io: Mock, stop: Mock) -> None:
    """
    Test `cli.stop_container()`.
    """
    cli.stop_container()
    make_io.assert_called_once()
    stop.assert_called_once()

@patch("sdc_docker.container.enter_shell")
@patch("sdc_docker.cli.make_io")
def test_enter_container_shell(
        make_io: Mock,
        enter_shell: Mock) -> None:
    """
    Test `cli.enter_container_shell()`.
    """
    cli.enter_container_shell()
    make_io.assert_called_once()
    enter_shell.assert_called_once()

@patch("sdc_docker.cli.make_io")
@patch("sdc_docker.remote_roslaunch.env_loader_in_login_shell")
def test_remote_roslaunch_env_loader(
        make_io: Mock,
        env_loader_in_login_shell: Mock) -> None:
    """
    Test `cli.remote_roslaunch_env_loader()`.
    """
    cli.remote_roslaunch_env_loader()
    make_io.assert_called_once()
    env_loader_in_login_shell.assert_called_once()
