"""
Test `sdc_docker.remote_roslaunch` module.
"""

import argparse
from subprocess import PIPE
from unittest.mock import Mock, patch

from sdc_docker import remote_roslaunch
from sdc_docker.io_impl import Io

def test_args_var_name() -> None:
    """
    Test `remote_roslaunch.args_var_name()`.
    """
    assert remote_roslaunch.args_var_name() == "__SDC_ENV_LOADER_ARGS"

@patch("sdc_docker.remote_roslaunch.run_script_in_login_shell")
def test_env_loader_in_login_shell(run_script_in_login_shell: Mock) -> None:
    """
    Test `remote_roslaunch.env_loader_in_login_shell()`.
    """
    io = Mock(Io)
    io.parse_arguments = Mock(
        return_value=argparse.Namespace(
            remaining=["roslaunch", "--some", "--arguments"],
        ))

    remote_roslaunch.env_loader_in_login_shell(io)

    run_script_in_login_shell.assert_called_once()
    assert run_script_in_login_shell.call_args.args[1] == \
        "from sdc_docker.io_impl import make_io; " \
        "import sdc_docker.remote_roslaunch as rr; " \
        "io = make_io(); " \
        "rr.env_loader(io)"
    io.putenv.assert_called_once_with( # type: ignore
        "__SDC_ENV_LOADER_ARGS",
        "roslaunch --some --arguments")

@patch("sdc_docker.remote_roslaunch.get_existing_containers",
    return_value=["some-container-name"])
@patch("sdc_docker.remote_roslaunch.run_arguments_inside_container")
def test_env_loader(
        run_arguments_inside_container: Mock,
        get_existing_containers: Mock) -> None: # pylint: disable=unused-argument
    """
    Test `remote_roslaunch.env_loader()`.
    """
    io = Mock(Io, getenv=lambda name: {
            "SDC_DOCKER_CONTAINER_NAME": "some-container-name",
            "__SDC_ENV_LOADER_ARGS": "roslaunch --other --args",
        }[name])
    remote_roslaunch.env_loader(io)

    run_arguments_inside_container.assert_called_once_with(
        io, "some-container-name", "roslaunch --other --args")

@patch("sdc_docker.container.run")
@patch("sdc_docker.remote_roslaunch.get_existing_containers",
    return_value=["some-container-name"])
@patch("sdc_docker.remote_roslaunch.run_arguments_inside_container")
def test_env_loader_start_new_container(
        run_arguments_inside_container: Mock,
        get_existing_containers: Mock, # pylint: disable=unused-argument
        container_run: Mock) -> None:
    """
    Test `remote_roslaunch.env_loader()` when container hasn't started yet.
    """
    io = Mock(Io, getenv=lambda name: {
            "HOME": "/home/some-user",
            "SDC_DOCKER_CONTAINER_NAME": "another-container-name",
            "__SDC_ENV_LOADER_ARGS": "roslaunch --another --args",
        }[name])
    remote_roslaunch.env_loader(io)

    container_run.assert_called_once()
    run_arguments_inside_container.assert_called_once_with(
        io, "another-container-name", "roslaunch --another --args")

def test_run_script_in_login_shell() -> None:
    """
    Test `remote_roslaunch.run_script_in_login_shell()`.
    """
    io = Mock(Io, sys_executable=lambda: "some-executable")
    remote_roslaunch.run_script_in_login_shell(io, "some-script")

    call_args = io.subprocess_run.call_args # type: ignore
    assert call_args.args[0] == \
        "bash -lc \"some-executable -c \'some-script\'\""

def test_get_existing_containers() -> None:
    """
    Test `remote_roslaunch.get_existing_containers()`.
    """
    io = Mock(Io)
    remote_roslaunch.get_existing_containers(io)
    io.subprocess_run.assert_called_once_with( # type: ignore
        "docker ps --all --format='{{.Names}}'",
        stdout=PIPE, shell=True, check=True)

def test_run_arguments_inside_container() -> None:
    """
    Test `remote_roslaunch.run_arguments_inside_container()`.
    """
    io = Mock(Io)
    remote_roslaunch.run_arguments_inside_container(
        io, "container-name", "some-arguments")
    io.subprocess_run.assert_called_once_with( # type: ignore
        "docker exec container-name "
        "bash -c \"source devel/setup.bash; some-arguments\"",
        shell=True, check=True)
