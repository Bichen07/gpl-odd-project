"""
Test `sdc_docker.utils` module.
"""

from pathlib import Path
from subprocess import PIPE
from unittest.mock import call, MagicMock, Mock

from pyrsistent import pmap
import pytest
from sdc_docker import utils
from sdc_docker.io_impl import Io

def test_bool_from_string_exception() -> None:
    """
    Test `utils.bool_from_string()`.
    """
    with pytest.raises(RuntimeError):
        utils.bool_from_string("some")
    with pytest.raises(RuntimeError):
        utils.bool_from_string("random")
    with pytest.raises(RuntimeError):
        utils.bool_from_string("text")

def test_pmap_project() -> None:
    """
    Test `utils.pmap_project()`.
    """
    data = {
        "some": 1,
        "random": True,
        "values": "abc"
    }
    assert utils.pmap_project(data, "some", "values") == \
        pmap({ "some": 1, "values": "abc" })

def test_undefined() -> None:
    """
    Test `utils.undefined()`.
    """
    with pytest.raises(RuntimeError):
        utils.undefined()

def test_zero_one_from_bool() -> None:
    """ Test `utils.zero_one_from_bool()`. """
    assert utils.zero_one_from_bool(True) == "1"
    assert utils.zero_one_from_bool(False) == "0"

def test_find_files() -> None:
    """ Test `utils.find_files()`. """
    io = MagicMock(Io)
    utils.find_files(io, "/usr/lib", "some-file", False)
    io.subprocess_run.assert_called_once_with(
        ["find", "/usr/lib", "-iname", "some-file"],
        check=True, stdout=PIPE)

def test_with_nothing() -> None:
    """ Test `utils.with_nothing()`. """
    with utils.with_nothing() as x:
        assert x is None

def test_temporary_directory() -> None:
    """ Test `utils.temporary_directory`. """
    io = Mock(Io)
    io.mkdtemp.return_value = Path("/some/path")
    m = Mock()
    m.attach_mock(io.mkdtemp, "mkdtemp")
    m.attach_mock(io.rmtree, "rmtree")
    with utils.temporary_directory(io, prefix="some-prefix") as temp_dir:
        assert temp_dir == Path("/some/path")
    assert m.method_calls == [
        call.mkdtemp(prefix="some-prefix"),
        call.rmtree(Path("/some/path")),
    ]
