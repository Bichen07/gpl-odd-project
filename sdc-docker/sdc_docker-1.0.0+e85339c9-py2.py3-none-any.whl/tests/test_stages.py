""" Test sdc_docker.stages module """

from unittest.mock import call, Mock, patch

from sdc_docker import stages
from sdc_docker.io_impl import Io

def test_docker_build() -> None:
    """ Test `stages.docker_build()`. """
    io = Mock(Io)
    stages.docker_build(
        io, { "a": "b", "c": "d" }, "some-dir", [ "e", "f" ], "some-tag")
    assert io.subprocess_run.mock_calls == [
        call([ "docker", "build",
            "--build-arg", "a=b",
            "--build-arg", "c=d", "e", "f",
            "--tag", "some-tag",
            "some-dir" ], check=True)]

def test_ros1_version() -> None:
    """ Test `stages.ros1_version()`. """
    assert stages.ros1_version("bionic") == "melodic"

@patch("sdc_docker.stages.temporary_directory")
@patch("sdc_docker.stages.docker_build")
def test_docker_build_from_template(
        docker_build: Mock,
        temporary_directory: Mock) -> None:
    """ Test `stages.docker_build_from_template()`. """
    temporary_directory.return_value.__enter__.return_value = "/some/temp/dir"
    io = Mock(Io)
    io.render_jinja_template.return_value = "<rendered-dockerfile>"
    m = Mock()
    m.attach_mock(temporary_directory, "temporary_directory")
    m.attach_mock(io.copytree, "copytree")
    m.attach_mock(io.render_jinja_template, "render_jinja_template")
    m.attach_mock(io.write_file, "write_file")
    m.attach_mock(docker_build, "docker_build")
    context = Mock()

    stages.docker_build_from_template(
        io,
        build_args={ "a": "b", "c": "d" },
        build_directory="/some/dir",
        extra_args=[ "e", "f" ],
        tag="some-tag",
        context=context)

    assert m.method_calls == [
        call.temporary_directory(io, prefix="sdc-docker-"),
        call.copytree("/some/dir", "/some/temp/dir",
            symlinks=True, dirs_exist_ok=True),
        call.render_jinja_template(
            "Dockerfile.jinja", searchpath="/some/temp/dir", context=context),
        call.write_file("/some/temp/dir/Dockerfile", "<rendered-dockerfile>"),
        call.docker_build(io, { "a": "b", "c": "d" }, "/some/temp/dir",
            [ "e", "f" ], "some-tag"),
    ]
