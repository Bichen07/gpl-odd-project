"""
Test image handling routines.
"""

from unittest.mock import ANY, call, Mock, patch

from pyrsistent import freeze
import pytest
from sdc_docker import image, stage1
from sdc_docker.io_impl import Io

@patch("sdc_docker.stage1.build")
@patch("sdc_docker.stage2.build")
def test_build_image(
        stage2_build: Mock,
        stage1_build: Mock) -> None:
    """ Test `image.build()`. """
    m = Mock()
    m.attach_mock(stage1_build, "stage1_build")
    m.attach_mock(stage2_build, "stage2_build")
    io = Mock(Io)
    io.parse_arguments = Mock(
        return_value=freeze({ "extra_args": [ "a", "b", "c" ], }))

    image.build(io)

    m.assert_has_calls([
        call.stage1_build(io, ["b", "c"]),
        call.stage2_build(io, ["b", "c"]),
    ])

@patch("sdc_docker.config.read")
@patch("sdc_docker.stage1.loaded_image_name")
def test_stage1_load_from_file(
        loaded_image_name: Mock,
        config_read: Mock) -> None:
    """
    Test `stage1.load_from_file()`.
    """
    io = Mock(Io)
    m = Mock()
    m.attach_mock(config_read, "config_read")
    m.attach_mock(io.subprocess_run, "run")
    loaded_image_name.return_value = "<loaded-image-name>"
    config_read.return_value = Mock(stage1_image="<cfg-image-name>")

    stage1.load_from_file(io, "some/file")

    assert m.method_calls == [
        call.config_read(io),
        call.run("docker load --input some/file",
            check=True, shell=True, stdout=ANY),
        call.run("docker tag <loaded-image-name> <cfg-image-name>",
            check=True, shell=True)
    ]

@patch("sdc_docker.stage1.loaded_image_name")
def test_stage1_download_over_ssh(
        loaded_image_name: Mock) -> None:
    """
    Test `stage1.download_over_ssh()`.
    """
    io = Mock(Io)
    loaded_image_name.return_value = "<loaded-image-name>"

    stage1.download_over_ssh(io, "some@upn", "some-image-name")

    assert io.subprocess_run.mock_calls == [
        call.run("ssh some@upn docker save some-image-name | docker load",
            check=True, shell=True, stdout=ANY),
        call.run("docker tag <loaded-image-name> some-image-name",
            check=True, shell=True)
    ]

def test_loaded_image_name() -> None:
    """
    Test `stage1.loaded_image_name()`.
    """
    docker_load_stdout = "Loaded image: some-image\n".encode("utf-8")
    assert stage1.loaded_image_name(docker_load_stdout) == "some-image"

@patch("sdc_docker.stage1.pull")
@patch("sdc_docker.stage2.build")
def test_image_update(pull: Mock, build: Mock) -> None:
    """
    Test `image.update()` when pulling stage-1 from docker repository.
    """
    io = Mock(Io)
    io.parse_arguments = Mock(
        return_value=freeze({
            "extra_args": [],
            "stage1_from_file": None,
            "stage1_from_ssh": None,
        }))
    image.update(io)
    pull.assert_called_once()
    build.assert_called_once()

@patch("sdc_docker.stage1.load_from_file")
@patch("sdc_docker.stage2.build")
def test_image_update_from_file(load: Mock, build: Mock) -> None:
    """
    Test `image.update()` when loading stage-1 from file.
    """
    io = Mock(Io)
    io.parse_arguments = Mock(
        return_value=freeze({
            "extra_args": [],
            "stage1_from_file": "/some/file/name",
            "stage1_from_ssh": None,
        }))
    image.update(io)
    load.assert_called_once()
    build.assert_called_once()

@patch("sdc_docker.config.read")
@patch("sdc_docker.stage1.download_over_ssh")
@patch("sdc_docker.stage2.build")
def test_image_download_over_ssh(
        s2_build: Mock,
        s1_download: Mock,
        config_read: Mock) -> None:
    """
    Test `image.update()` when downloading stage-1 over SSH.
    """
    m = Mock()
    m.attach_mock(config_read, "config_read")
    m.attach_mock(s1_download, "s1_download")
    m.attach_mock(s2_build, "s2_build")

    io = Mock(Io)
    io.parse_arguments = Mock(
        return_value=freeze({
            "extra_args": [],
            "stage1_from_file": None,
            "stage1_from_ssh": "user@address"
        }))

    image.update(io)

    m.assert_has_calls([
        call.config_read(io),
        call.s1_download(io, "user@address", ANY),
        call.s2_build(io, extra_args=[]),
        ])

def test_build_image_no_data_directory() -> None:
    """
    Make sure we throw an exception if `data/docker` directory
    isn't present.
    """
    io = Mock(Io)
    io.file_exists = Mock(return_value=False)

    with pytest.raises(RuntimeError):
        image.build(io)
