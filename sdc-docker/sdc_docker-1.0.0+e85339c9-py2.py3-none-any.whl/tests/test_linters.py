"""
Run various linters on the source code of the package.
"""

from pathlib import Path
import subprocess

import mypy.api

def test_mypy() -> None:
    """
    Check the source code of the package with mypy.
    """
    sdc_docker_directory = package_directory() / "sdc_docker"
    tests_directory = package_directory() / "tests"
    result = mypy.api.run(args=[
        "--disallow-untyped-defs",
        "--no-incremental",
        "--exclude", "/integration/remote-launch/ros-workspace/",
        str(sdc_docker_directory),
        str(tests_directory)])
    assert result[2] == 0, f"\n{result[0]}"

def test_pylint() -> None:
    """
    Check the source code of the package with pylint.
    """
    result = subprocess.run(["pylint", # pylint: disable=subprocess-run-check
        "--disable", "implicit-str-concat",
        "--disable", "wrong-import-order",
        "--extension-pkg-allow-list=mypy",
        "--persistent=n",
        "--rcfile", package_directory() / "tests" / "pylintrc-test",
        package_directory() / "sdc_docker",
        package_directory() / "tests",
    ], stdout=subprocess.PIPE)
    return_code = result.returncode
    assert return_code == 0, result.stdout.decode("utf-8")

def package_directory() -> Path:
    """
    Returns path to the root directory of the repository.
    """
    return Path(__file__).parent.parent
