"""
Test `sdc_docker.container` module.
"""

from contextlib import ExitStack
from subprocess import PIPE
from typing import Callable # pylint: disable=unused-import
from typing import List
from unittest.mock import ANY, call, Mock, patch

from pyrsistent import freeze, PVector
from sdc_docker import container
from sdc_docker.container import option, options
from sdc_docker.io_impl import Io

def test_local_version_identifier() -> None:
    """
    Test `container.local_version_identifier()`.
    """
    assert container.local_version_identifier("1.0.0") is None
    assert container.local_version_identifier("1.0.0+") is None
    assert container.local_version_identifier("1.0.0+a") == "a"

def test_remote_revision_url() -> None:
    """
    Test `container.remote_revision_url()`.
    """
    assert container.remote_revision_url() == \
        "https://dev.mupher.com:20002/nextcloud/index.php/s/" \
            "n3MWSJiLXWCyYtR/download"

@patch("sdc_docker.container.gather_facts")
@patch("sdc_docker.container.docker_stop")
def test_stop(docker_stop: Mock, gather_facts: Mock) -> None:
    """ Test `container.stop()`. """
    io = Mock(Io)
    m = Mock()
    m.attach_mock(gather_facts, "gather_facts")
    m.attach_mock(docker_stop, "docker_stop")
    gather_facts.return_value = Mock(config=Mock(container_name="some-name"))

    container.stop(io)

    assert m.method_calls == [
        call.gather_facts(io),
        call.docker_stop(io, "some-name"),
    ]

@patch("sdc_docker.container.gather_facts")
@patch("sdc_docker.container.enter_shell_command",
    return_value="enter_shell_command")
def test_enter_shell(
        enter_shell_command: Mock, # pylint: disable=unused-argument
        gather_facts: Mock) -> None:
    """ Test `container.enter_shell()`. """

    io = Mock(Io)
    m = Mock()
    m.attach_mock(gather_facts, "gather_facts")
    m.attach_mock(io.subprocess_run, "subprocess_run")

    container.enter_shell(io)

    assert m.method_calls == [
        call.gather_facts(io),
        call.subprocess_run("enter_shell_command", shell=True, check=True),
    ]

@patch("sdc_docker.container.audio_configured")
@patch("sdc_docker.container.gather_facts")
@patch("sdc_docker.container.docker_run")
@patch("sdc_docker.container.docker_options")
@patch("sdc_docker.container.report_dict")
@patch("sdc_docker.container.check_revision")
@patch("dataclasses.asdict")
def test_run( # pylint: disable=too-many-arguments
        asdict: Mock, # pylint: disable=unused-argument
        check_revision: Mock,
        report_dict: Mock, # pylint: disable=unused-argument
        docker_options: Mock, # pylint: disable=unused-argument
        docker_run: Mock,
        gather_facts: Mock,
        audio_configured: Mock) -> None:
    """ Test `container.run()`. """

    io = Mock(Io)
    m = Mock()
    m.attach_mock(gather_facts, "gather_facts")
    m.attach_mock(io.log, "log")
    m.attach_mock(audio_configured, "audio_configured")
    m.attach_mock(docker_run, "docker_run")
    m.attach_mock(check_revision, "check_revision")

    container.run(io, options(option("extra", "options")))

    assert m.method_calls == [
        call.gather_facts(io),
        call.log("Facts:"),
        call.log(ANY),
        call.log("Docker options:"),
        call.log("  --extra options"),
        call.audio_configured(io),
        call.docker_run(io,
            opts=options(option("extra", "options")),
            user_opts=ANY,
            image_name=ANY,
            command=ANY),
        call.check_revision(io, ANY),
    ]

@patch("sdc_docker.config.read")
@patch("sdc_docker.container.find_libnvcuvid")
@patch("sdc_docker.container.find_nvidia_driver_directory")
def test_gather_facts(
        find_libnvcuvid: Mock,
        find_nvidia_driver_directory: Mock,
        config_read: Mock) -> None:
    """ Test `container.gather_facts()`. """

    find_libnvcuvid.return_value = "/lib/nvcuvid"
    find_nvidia_driver_directory.return_value = "/lib/nvidia"
    config = Mock()
    config_read.return_value = config
    io = Mock(Io)
    io.file_exists = lambda name: {
            "/dev/nvidia-modeset": True,
        }[name]
    io.getenv = lambda name: {
            "HOME": "/host/home",
        }[name]

    facts = container.gather_facts(io)
    assert facts == container.Facts(
        config=config,
        has_nvidia_modeset=True,
        host_home="/host/home",
        libnvcuvid_path="/lib/nvidia",
        nvidia_driver_directory="/lib/nvcuvid")

    config = Mock()
    config.nvidia_support_enabled = False
    config_read.return_value = config
    facts = container.gather_facts(io)
    assert facts == container.Facts(
        config=config,
        has_nvidia_modeset=False,
        host_home="/host/home",
        libnvcuvid_path="",
        nvidia_driver_directory="")

@patch("sdc_docker.container.load_pulseaudio_module", return_value=42)
@patch("sdc_docker.container.configure_pulseaudio")
@patch("sdc_docker.container.unload_pulseaudio_module")
@patch("sdc_docker.container.release_pulseaudio")
def test_audio_configure(
        release_pulseaudio: Mock,
        unload_pulseaudio_module: Mock,
        configure_pulseaudio: Mock,
        load_pulseaudio_module: Mock) -> None:
    """ Test `container.audio_configured()`. """

    m = Mock()
    m.attach_mock(release_pulseaudio, "release_pulseaudio")
    m.attach_mock(unload_pulseaudio_module, "unload_pulseaudio_module")
    m.attach_mock(configure_pulseaudio, "configure_pulseaudio")
    m.attach_mock(load_pulseaudio_module, "load_pulseaudio_module")
    io = Mock(Io)

    with container.audio_configured(io):
        assert m.mock_calls == [
            call.load_pulseaudio_module(io),
            call.configure_pulseaudio(io),
        ]
        m.mock_calls.clear()

    assert m.mock_calls == [
        call.unload_pulseaudio_module(io, 42),
        call.release_pulseaudio(io),
    ]

def test_load_pulseaudio_module() -> None:
    """ Test `container.load_pulseaudio_module()`. """
    io = Mock(Io)
    io.subprocess_run = Mock(return_value=Mock(stdout="42".encode("utf-8")))
    module_id = container.load_pulseaudio_module(io)
    assert module_id == 42
    io.subprocess_run.assert_called_once_with(
        ["pactl", "load-module", "module-native-protocol-unix",
            "socket=/tmp/sdc-docker-pulseaudio.socket"],
        stdout=PIPE, check=True)

def test_unload_pulseaudio_module() -> None:
    """ Test `container.unload_pulseaudio_module()`. """
    io = Mock(Io)
    container.unload_pulseaudio_module(io, 42)
    io.subprocess_run.assert_called_once_with(
        ["pactl", "unload-module", "42"], check=True)

def test_configure_pulseaudio() -> None:
    """ Test `container.configure_pulseaudio()`. """
    io = Mock(Io)
    container.configure_pulseaudio(io)
    io.write_file.assert_called_once_with(
        "/tmp/sdc-docker-pulseaudio-client.conf",
        "default-server = unix:/tmp/sdc-docker-pulseaudio.socket\n"
        "autospawn = no\n"
        "daemon-binary = /bin/true\n"
        "enable-shm = false\n")

def test_release_pulseaudio() -> None:
    """ Test `container.release_pulseaudio()`. """
    io = Mock(Io)
    container.release_pulseaudio(io)
    io.subprocess_run.assert_called_once_with(
        ["rm", "/tmp/sdc-docker-pulseaudio-client.conf"], check=True)

def test_docker_run() -> None:
    """ Test `container.docker_run()`. """
    io = Mock(Io)
    container.docker_run(
        io,
        opts=options(
            option("a", "b"),
            option("c", None),
            option("d", "e")),
        user_opts="--some user --options",
        image_name="some-image-name",
        command="some-command")
    io.subprocess_run.assert_called_once_with(
        "docker run --a b --c --d e --some user --options "
        "some-image-name some-command", check=True, shell=True)

def test_docker_stop() -> None:
    """ Test `container.docker_stop()`. """
    io = Mock(Io)
    container.docker_stop(io, "some-name")
    io.subprocess_run.assert_called_once_with(
        "docker stop some-name", check=True, shell=True)

def test_get_nvidia_driver_version() -> None:
    """ Test `container.get_nvidia_driver_version()`. """
    io = Mock(Io)
    io.subprocess_run = Mock(
        return_value=Mock(
            stdout="Driver Version : 1.2.3".encode("utf-8")))
    out = container.get_nvidia_driver_version(io)
    assert out == { "major": "1", "minor": "2", "patch": "3" }

@patch("sdc_docker.container.get_nvidia_driver_version")
@patch("sdc_docker.container.find_files", return_value=["/some/path"])
def test_find_nvidia_driver_directory(
        find_files: Mock, # pylint: disable=unused-argument
        get_nvidia_driver_version: Mock) -> None: # pylint: disable=unused-argument
    """ Test `container.find_nvidia_driver_directory()`. """
    io = Mock(Io)
    out = container.find_nvidia_driver_directory(io)
    assert out == "/some"

@patch("sdc_docker.container.get_nvidia_driver_version")
@patch("sdc_docker.container.find_files", return_value=["some-path"])
def test_find_libnvcuvid(
        find_files: Mock, # pylint: disable=unused-argument
        get_nvidia_driver_version: Mock) -> None: # pylint: disable=unused-argument
    """ Test `container.find_libnvcuvid()`. """
    io = Mock(Io)
    out = container.find_libnvcuvid(io)
    assert out == "some-path"

@patch("sdc_docker.container.revision_mismatch_message")
@patch("sdc_docker.container.revision_checking_failure_message")
def test_check_revision(
        failure_message: Mock,
        mismatch_message: Mock) -> None:
    """
    Test `container.check_revision()`.
    """

    revision = "1" * 40

    io = Mock(Io)
    io.version = Mock(return_value=f"1.0.0+{revision[:8]}")
    io.subprocess_run = \
        Mock(return_value=Mock(stdout=f"{revision}\n".encode("utf-8")))

    container.check_revision(io, True)
    mismatch_message.assert_not_called()
    failure_message.assert_not_called()

@patch("sdc_docker.container.revision_mismatch_message")
@patch("sdc_docker.container.revision_checking_failure_message")
def test_check_revision_mismatch(
        failure_message: Mock,
        mismatch_message: Mock) -> None:
    """
    Test `container.check_revision()` when revisions mismatch.
    """
    revision1 = "1" * 40
    revision2 = "2" * 40

    io = Mock(Io)
    io.version = Mock(return_value=f"1.0.0+{revision1[:8]}")
    io.subprocess_run = \
        Mock(return_value=Mock(stdout=f"{revision2}\n".encode("utf-8")))

    container.check_revision(io, True)

    mismatch_message.assert_called_once()
    failure_message.assert_not_called()

@patch("sdc_docker.container.revision_checking_failure_message")
def test_check_revision_failure(failure_message: Mock) -> None:
    """
    Test `container.check_revision()` when failed to retrieve remote revision.
    """
    revision = "some invalid revision"

    io = Mock(Io)
    io.subprocess_run = \
        Mock(return_value=Mock(stdout=f"{revision}\n".encode("utf-8")))

    container.check_revision(io, True)

    failure_message.assert_called_once()

def test_prepare_bash_history() -> None:
    """
    Test `container.prepare_bash_history()` when the history file doesn't
    exists.
    """
    io = Mock(Io)
    io.getenv = lambda name: { "HOME": "/home/some-user", }[name]
    io.file_exists = Mock(return_value=False)
    container.prepare_bash_history(io)
    io.write_file.assert_called_once_with(
        "/home/some-user/.sdc-docker-bash-history", "")

def test_report_docker_options() -> None:
    """ Test `container.report_docker_options()`. """
    report = container.report_docker_options(options(
        option("some", None),
        option("other", "option"),
        option("yet", "another")))
    assert report == \
        "--other option\n" \
        "--some  \n" \
        "--yet   another"

def test_indent() -> None:
    """ Test `container.indent()`. """
    assert container.indent(1, "a\nb") == " a\n b"

def test_docker_options() -> None:
    """ Test `container.docker_options()`. """

    functions_to_patch = {
        "apparmor_unconfined_option",
        "audio_options",
        "container_name_option",
        "container_user_option",
        "container_working_directory_option",
        "detached_mode_option",
        "graphics_options",
        "mount_host_bash_history",
        "mount_user_volumes_options",
        "networking_options",
        "nvidia_options",
        "remove_container_after_finished_option",
    }

    def patch_functions() -> ExitStack:
        """ Make each of the patched functions return its name. This way
        we can tell which options were passed to `container.options()`. """
        stack = ExitStack()
        for f in functions_to_patch:
            stack.enter_context(
                patch(f"sdc_docker.container.{f}", return_value=f))
        return stack

    def patched_options(*opts: str) -> List[str]:
        """ Return a list of provided options, not including output of
        `container.empty_option()`. This will aggregate the list of
        function names that were passsed to `container.options()`. """
        return list(filter(lambda opt: opt != [], opts))

    with patch("sdc_docker.container.options", side_effect=patched_options):
        with patch_functions():
            facts = Mock()
            output = set(container.docker_options(facts))
            assert output == functions_to_patch

            facts = Mock(config=Mock(audio_enabled=False))
            output2 = set(container.docker_options(facts))
            assert output.difference(output2) == { "audio_options" }
            assert output2.difference(output) == set()

            facts = Mock(config=Mock(detached_mode_enabled=False))
            output2 = set(container.docker_options(facts))
            assert output.difference(output2) == { "detached_mode_option" }
            assert output2.difference(output) == set()

            facts = Mock(config=Mock(graphics_enabled=False))
            output2 = set(container.docker_options(facts))
            assert output.difference(output2) == { "graphics_options" }
            assert output2.difference(output) == set()

            facts = Mock(config=Mock(nvidia_support_enabled=False))
            output2 = set(container.docker_options(facts))
            assert output.difference(output2) == { "nvidia_options" }
            assert output2.difference(output) == set()

def test_command_line_docker_options() -> None:
    """ Test `container.command_line_docker_options()`. """
    assert container.command_line_docker_options(
        options(
            option("a", "b"),
            option("c", None),
            option("d", "e"))) == ["--a", "b", "--c", "--d", "e"]

def test_apparmor_unconfined_option() -> None:
    """ Test `container.apparmor_unconfined_option()`. """
    assert container.apparmor_unconfined_option() == \
        option("security-opt", "apparmor:unconfined")

def test_audio_options() -> None:
    """ Test `container.audio_options()`. """
    assert container.audio_options() == \
        options(
            option("device", "/dev/snd"),
            option("env", "PULSE_COOKIE=/tmp/sdc-docker-pulseaudio.cookie"),
            option("env",
                "PULSE_SERVER=unix:/tmp/sdc-docker-pulseaudio.socket"),
            option("volume",
                "/tmp/sdc-docker-pulseaudio-client.conf:"
                "/tmp/sdc-docker-pulseaudio-client.conf:ro"),
            option("volume",
                "/tmp/sdc-docker-pulseaudio.socket:"
                "/tmp/sdc-docker-pulseaudio.socket")
        )

def test_container_name_option() -> None:
    """ Test `container.container_name_option()`. """
    assert container.container_name_option("some-name") == \
        option("name", "some-name")

def test_container_user_option() -> None:
    """ Test `container.container_user_option()`. """
    assert container.container_user_option() == \
        option("user", "user")

def test_container_working_directory_option() -> None:
    """ Test `container.container_working_directory_option(). """
    assert container.container_working_directory_option("some/dir") == \
        option("workdir", "some/dir")

def test_detached_mode_options() -> None:
    """ Test `container.detached_mode_option()`. """
    assert container.detached_mode_option() == option("detach", None)

def test_graphics_options() -> None:
    """ Test `container.graphics_options()`. """
    assert container.graphics_options() == \
        options(
            option("env", "DISPLAY"),
            option("volume", "/tmp/.X11-unix:/tmp/.X11-unix"),
        )

def test_mount_host_bash_history() -> None:
    """ Test `container.mount_host_bash_history()`. """
    assert container.mount_host_bash_history("host/home", "cont/home") == \
        option("volume",
            "host/home/.sdc-docker-bash-history:"
            "cont/home/.bash_history:rw")

def test_mount_user_volumes_options() -> None:
    """ Test `container.mount_user_volumes_options()`. """
    assert container.mount_user_volumes_options([
            "some:volume:ro",
            "another:vol:rw",
            "yet:another",
        ]) == options(
            option("volume", "some:volume:ro"),
            option("volume", "another:vol:rw"),
            option("volume", "yet:another"),
        )

def test_networking_options() -> None:
    """ Test `container.networking_options()`. """
    facts = Mock(host_home="/home/host-user")
    assert container.networking_options(facts) == \
        options(
            option("cap-add", "NET_ADMIN"),
            option("network", "host"),
            option("volume", "/home/host-user/.ssh:/home/user/.ssh:ro"),
        )

def test_nvidia_options() -> None:
    """ Test `container.nvidia_options()`. """
    facts = Mock(
        has_nvidia_modeset=True,
        nvidia_driver_directory="some/dir",
        libnvcuvid_path="some/path")
    assert container.nvidia_options(facts) == \
        options(
            option("device", "/dev/nvidia-modeset"),
            option("volume",
                "some/dir/vdpau:/usr/lib/x86_64-linux-gnu/vdpau:ro"),
            option("env", "NVIDIA_VISIBLE_DEVICES=all"),
            option("env",
                "NVIDIA_DRIVER_CAPABILITIES=compute,graphics,utility"),
            option("gpus", "all"),
            option("volume", "some/path:/usr/lib/libnvcuvid.so:ro"),
            option("mount",
                "type=bind"
                ",src=some/dir/libnvidia-encode.so"
                ",dst=/usr/lib/x86_64-linux-gnu/libnvidia-encode.so"
                ",readonly"),
        )

    facts = Mock(
        config=Mock(vaapi_enabled=False),
        has_nvidia_modeset=False,
        nvidia_driver_directory="some/dir",
        libnvcuvid_path="some/path")
    assert container.nvidia_options(facts) == \
        options(
            option("env", "NVIDIA_VISIBLE_DEVICES=all"),
            option("env",
                "NVIDIA_DRIVER_CAPABILITIES=compute,graphics,utility"),
            option("gpus", "all"),
            option("volume", "some/path:/usr/lib/libnvcuvid.so:ro"),
            option("mount",
                "type=bind"
                ",src=some/dir/libnvidia-encode.so"
                ",dst=/usr/lib/x86_64-linux-gnu/libnvidia-encode.so"
                ",readonly"),
        )

def test_remove_container_after_finished_option() -> None:
    """ Test `container.remove_container_after_finished_option()`. """
    assert container.remove_container_after_finished_option() == \
        [("rm", None)]

def test_enter_shell_command() -> None:
    """ Test `container.enter_shell_command()`. """
    facts = Mock(
        config=Mock(
            container_name="some-container"))
    assert container.enter_shell_command(facts) == \
        "docker exec " \
        "--env TERM=xterm-256color " \
        "--interactive " \
        "--tty " \
        "--user user " \
        "some-container " \
        "/usr/local/sdc-docker/bin/enter-container-shell"

def test_empty_option() -> None:
    """ Test `container.empty_option()`. """
    assert container.empty_option() == []

def test_option() -> None:
    """ Test `container.option()`. """
    assert container.option("a", "b") == [("a", "b")]
    assert container.option("a", None) == [("a", None)]

def test_options() -> None:
    """ Test `container.options()`. """
    assert container.options(
        freeze([("a", "b"), ("c", None)]),
        freeze([("d", None), ("e", "f")])) == \
       [("a", "b"), ("c", None), ("d", None), ("e", "f")]

def test_conatiner_home() -> None:
    """ Test `container.home()`. """
    assert container.container_home() == "/home/user"

def test_pulseaudio_client_conf_path() -> None:
    """ Test `container.pulseaudio_client_conf_path()`. """
    assert container.pulseaudio_client_conf_path() == \
        "/tmp/sdc-docker-pulseaudio-client.conf"

def test_pulseaudio_socket_path() -> None:
    """ Test `container.pulseaudio_socket_path()`. """
    assert container.pulseaudio_socket_path() == \
        "/tmp/sdc-docker-pulseaudio.socket"

def test_valid_revision() -> None:
    """ Test `container.valid_revision()`. """
    assert container.valid_revision("1234abc")
    assert not container.valid_revision("1234abcg")
    assert not container.valid_revision("0" * 41)

def assert_is_options(x: container.Options) -> None:
    """
    Utility function for checking type of `container.Options` objects.
    """
    assert isinstance(x, PVector)
    map(assert_is_tuple, x)

def assert_is_tuple(x: tuple) -> None:
    """
    Utility function for checking type of `tuple` objects.
    """
    assert isinstance(x, tuple)
