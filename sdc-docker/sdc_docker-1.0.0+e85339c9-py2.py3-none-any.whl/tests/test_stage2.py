""" Test sdc_docker.stage2 module. """

from unittest.mock import ANY, Mock, patch

from sdc_docker import stage2
from sdc_docker.io_impl import Io

@patch("sdc_docker.config.read")
@patch("sdc_docker.stage2.docker_build_args")
@patch("sdc_docker.stages.docker_build")
def test_build(
        docker_build: Mock,
        docker_build_args: Mock, # pylint: disable=unused-argument
        config_read: Mock) -> None: # pylint: disable=unused-argument
    """ Test `stage2.build()`. """
    io = Mock(Io)
    stage2.build(io, ["extra", "args"])
    docker_build.assert_called_once_with(io,
        build_args=ANY,
        build_directory=ANY,
        extra_args=["extra", "args"],
        tag=ANY)

def test_docker_build_args() -> None:
    """ Test `stage2.docker_build_args()`. """
    config = Mock()
    config.stage1_image = "image-name"
    config.ubuntu_version = "bionic"
    facts = stage2.BuildFacts(
        config=config,
        docker_build_directory="build/dir",
        extra_args=["extra", "args"],
        host_user_gid=12,
        host_user_uid=34,
    )
    assert stage2.docker_build_args(facts) == {
            "SDC_DOCKER_CONTAINER_USER": "user",
            "SDC_DOCKER_HOST_USER_GID": "12",
            "SDC_DOCKER_HOST_USER_UID": "34",
            "SDC_DOCKER_STAGE1_IMAGE": "image-name",
            "SDC_ROS1_VERSION": "melodic",
            }
