"""
Test `sdc_docker.stage1` module
"""

from unittest.mock import ANY, call, MagicMock, Mock, patch

from sdc_docker import stage1
from sdc_docker.io_impl import Io

@patch("sdc_docker.config.read")
@patch("sdc_docker.stage1.docker_build_args")
@patch("sdc_docker.stages.docker_build_from_template")
def test_build(
        docker_build_from_template: Mock,
        docker_build_args: Mock, # pylint: disable=unused-argument
        config_read: Mock) -> None: # pylint: disable=unused-argument
    """ Test `stage1.build()`. """
    io = MagicMock(Io)
    stage1.build(io, ["extra", "args"])
    docker_build_from_template.assert_called_once_with(io,
        build_args=ANY,
        build_directory=ANY,
        extra_args=["extra", "args"],
        tag=ANY,
        context={ "facts": ANY }
    )

def test_pull() -> None:
    """
    Test `stage1.pull()`.
    """
    io = Mock(Io, getenv=lambda name: {
            "SDC_DOCKER_STAGE1_IMAGE": "some-image-name",
        }[name])
    stage1.pull(io)
    io.subprocess_run.assert_has_calls([ # type: ignore
        call("docker pull sdcdoc/sdc-stage-1", check=True, shell=True),
        call("docker tag sdcdoc/sdc-stage-1 some-image-name",
            check=True, shell=True),
    ])

def test_docker_build_args() -> None:
    """ Test `stage1.docker_build_args()`. """
    facts = Mock(
        config=Mock(
            building_git_enabled=True,
            ssl_verification_enabled=False,
            mirror_selection_enabled=True,
            ubuntu_version="bionic",
            vaapi_enabled=False),
        timezone="Some/Timezone")
    assert stage1.docker_build_args(facts) == {
        "SDC_DOCKER_BUILDING_GIT_ENABLED": "1",
        "SDC_DOCKER_SSL_VERIFICATION_ENABLED": "0",
        "SDC_DOCKER_MIRROR_SELECTION_ENABLED": "1",
        "SDC_DOCKER_UBUNTU_VERSION": "bionic",
        "SDC_ROS1_VERSION": "melodic",
        "TIMEZONE": "Some/Timezone",
    }
